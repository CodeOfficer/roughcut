---
title: Slide Numbers
category: features
directives:
  - "(none - configured via config only)"
related_config:
  - "slideNumber"
  - "showSlideNumber"
dom_requirements: false
---

# Slide Numbers

RevealJS can display slide numbers in the presentation to help users track their progress. Slide numbers are highly configurable in both format and visibility context.

---

## Basic Usage

Enable slide numbers by setting the `slideNumber` configuration option to `true`:

```javascript
Reveal.initialize({
  slideNumber: true
});
```

**Default behavior:**
- Shows slide numbers in bottom-right corner (theme-dependent)
- Format: `h.v` (horizontal.vertical)
- Displays in all contexts (presentation, speaker view, PDF)

---

## Format Options

The `slideNumber` configuration accepts several format strings or a custom function.

### Built-in Format Strings

```javascript
Reveal.initialize({
  slideNumber: 'h.v'  // Format string
});
```

| Format | Example | Description |
|--------|---------|-------------|
| `h.v` | `2.3` | Horizontal . Vertical (default) |
| `h/v` | `2/3` | Horizontal / Vertical |
| `c` | `5` | Flattened count (all slides sequentially numbered) |
| `c/t` | `5/12` | Current / Total (flattened count with total) |

**Format explanation:**
- **h** = Horizontal slide index (main slide number)
- **v** = Vertical slide index (sub-slide number within a stack)
- **c** = Current slide (flattened sequential numbering)
- **t** = Total slide count

### Examples

#### Horizontal/Vertical Format (Default)

```javascript
Reveal.initialize({
  slideNumber: 'h.v'  // or 'h/v'
});
```

**With this structure:**
```
Slide 1.0 � Slide 2.0 � Slide 3.0
            �
            Slide 2.1
            �
            Slide 2.2
```

**Displays:**
- Slide 1: `1.0` or `1/0`
- Slide 2 (main): `2.0` or `2/0`
- Slide 2 (first vertical): `2.1` or `2/1`
- Slide 2 (second vertical): `2.2` or `2/2`
- Slide 3: `3.0` or `3/0`

#### Flattened Count Format

```javascript
Reveal.initialize({
  slideNumber: 'c'  // or 'c/t'
});
```

**With the same structure above:**
- Slide 1: `1` or `1/5`
- Slide 2 (main): `2` or `2/5`
- Slide 2 (first vertical): `3` or `3/5`
- Slide 2 (second vertical): `4` or `4/5`
- Slide 3: `5` or `5/5`

**Use case:** Simple progress tracking regardless of vertical slide structure.

---

## Custom Slide Number Function

For full control, provide a custom function that returns the slide number string:

```javascript
Reveal.initialize({
  slideNumber: (slide) => {
    // Get indices for this slide
    const indices = Reveal.getIndices(slide);

    // Only show horizontal index (ignore vertical slides)
    return [indices.h];
  }
});
```

### Custom Function Parameters

```javascript
slideNumber: (slide) => {
  const indices = Reveal.getIndices(slide);
  // indices.h = horizontal index
  // indices.v = vertical index
  // indices.f = fragment index (optional)

  return ['Slide ' + (indices.h + 1)]; // Custom format
}
```

**Return value:**
- Must return an array of strings/numbers
- Array elements are joined to create the final display
- Example: `return [indices.h, '.', indices.v];` � "2.3"

### Custom Function Examples

#### Show Only Main Slide Numbers

```javascript
Reveal.initialize({
  slideNumber: (slide) => {
    return [Reveal.getIndices(slide).h + 1];
  }
});
```

#### Add Custom Prefix

```javascript
Reveal.initialize({
  slideNumber: (slide) => {
    const { h, v } = Reveal.getIndices(slide);
    return ['Page ', h + 1, v > 0 ? '.' + v : ''];
  }
});
// Result: "Page 2", "Page 2.1", "Page 2.2", etc.
```

#### Show Section Names

```javascript
Reveal.initialize({
  slideNumber: (slide) => {
    const section = slide.getAttribute('data-section');
    const { h } = Reveal.getIndices(slide);
    return [section || ('Section ' + (h + 1))];
  }
});
```

---

## Display Context Control

The `showSlideNumber` option controls **where** slide numbers appear.

```javascript
Reveal.initialize({
  slideNumber: true,
  showSlideNumber: 'all'  // Context
});
```

### Context Options

| Value | Description | Use Case |
|-------|-------------|----------|
| `all` | Show in all contexts (default) | Always show slide numbers |
| `print` | Only when printing to PDF | Include in PDFs, hide during presentation |
| `speaker` | Only in speaker view | Help presenter track progress |

### Examples

#### Print-Only Slide Numbers

```javascript
Reveal.initialize({
  slideNumber: 'c/t',
  showSlideNumber: 'print'
});
```

**Result:** Slide numbers appear in PDF exports but not during live presentation.

#### Speaker-Only Slide Numbers

```javascript
Reveal.initialize({
  slideNumber: true,
  showSlideNumber: 'speaker'
});
```

**Result:** Presenter sees slide numbers in speaker view; audience does not.

---

## DOM Structure

When slide numbers are enabled, RevealJS automatically injects a display element:

```html
<div class="reveal">
  <div class="slides">
    <!-- Your slides -->
  </div>

  <!-- Automatically injected by RevealJS -->
  <div class="slide-number">
    <span class="slide-number-delimiter">/</span>
    <span>2</span>
    <span class="slide-number-delimiter">/</span>
    <span>5</span>
  </div>
</div>
```

**Structure details:**
- Container: `<div class="slide-number">`
- Positioned via CSS (typically bottom-right)
- Updated automatically on slide change
- Can be styled via custom CSS

### Custom Styling

```css
.reveal .slide-number {
  position: absolute;
  bottom: 10px;
  right: 10px;
  font-size: 14px;
  color: #fff;
  background: rgba(0, 0, 0, 0.4);
  padding: 5px 10px;
  border-radius: 3px;
}

/* Hide the delimiter */
.reveal .slide-number-delimiter {
  display: none;
}
```

---

## Project Integration Notes

### Configuration in Markdown-Driven Builder

Since slide numbers are configured globally (not per-slide), they should be set in the presentation configuration:

```yaml
# presentation-config.yaml
slideNumber: c/t
showSlideNumber: all
```

**Generated HTML:**

```javascript
Reveal.initialize({
  slideNumber: 'c/t',
  showSlideNumber: 'all',
  // ... other config
});
```

### No Per-Slide Directives Needed

Unlike attributes like `data-background-color`, slide numbers don't have per-slide configuration. They're presentation-wide settings.

**Not applicable:**
```markdown
## My Slide
@slide-number: off  � NOT A THING
```

---

## Video Recording Considerations

### Visual Appearance

**Slide numbers appear in video recordings when:**
- `showSlideNumber` is set to `all` (default)
- Recording captures browser viewport

**Considerations for video:**

1. **Positioning**: Ensure slide numbers don't overlap important content
2. **Visibility**: Check contrast against slide backgrounds
3. **Consistency**: Use same format throughout video for professional appearance

### Recommended Settings for Video

```javascript
Reveal.initialize({
  // Show current/total for viewer orientation
  slideNumber: 'c/t',

  // Show in all contexts (including video)
  showSlideNumber: 'all'
});
```

### Timing Impact

**No timing impact** - Slide numbers update instantly on slide change with no animation delay.

---

## Configuration Reference

### slideNumber

**Type:** `boolean | string | function`
**Default:** `false`

| Value | Effect |
|-------|--------|
| `false` | Slide numbers disabled (default) |
| `true` | Slide numbers enabled with default format (`h.v`) |
| `'h.v'` | Horizontal . Vertical format |
| `'h/v'` | Horizontal / Vertical format |
| `'c'` | Flattened sequential count |
| `'c/t'` | Current / Total count |
| `function` | Custom function returning slide number |

### showSlideNumber

**Type:** `string`
**Default:** `'all'`

| Value | When Visible |
|-------|-------------|
| `'all'` | Presentation, speaker view, PDF (default) |
| `'print'` | PDF exports only |
| `'speaker'` | Speaker view only |

---

## Validation Requirements

When generating presentations with slide numbers:

1.  Ensure `slideNumber` is a valid value (boolean, string, or function)
2.  If using format string, verify it's one of: `h.v`, `h/v`, `c`, `c/t`
3.  If using custom function, ensure it returns an array
4.  Verify `showSlideNumber` is one of: `all`, `print`, `speaker`
5.  Test slide number visibility against various background colors

---

## Common Use Cases

### Simple Sequential Numbering

```javascript
Reveal.initialize({
  slideNumber: 'c'
});
```

**Best for:** Linear presentations without vertical slides.

### Progress Tracking

```javascript
Reveal.initialize({
  slideNumber: 'c/t'
});
```

**Best for:** Long presentations where audience wants to know progress.

### Hierarchical Navigation

```javascript
Reveal.initialize({
  slideNumber: 'h.v'
});
```

**Best for:** Presentations with nested content (vertical slides).

### PDF-Only

```javascript
Reveal.initialize({
  slideNumber: 'c/t',
  showSlideNumber: 'print'
});
```

**Best for:** Clean live presentation with numbered PDF handouts.

---

## API Access

While slide numbers are typically configured at initialization, you can access slide number information programmatically:

```javascript
// Get current slide indices
const indices = Reveal.getIndices();
console.log(indices.h, indices.v); // horizontal, vertical

// Get total slide count (flattened)
const totalSlides = Reveal.getTotalSlides();

// Get current slide element
const currentSlide = Reveal.getCurrentSlide();
```

**See also:**
- [31-api-methods.md](31-api-methods.md) - API reference
- [32-events.md](32-events.md) - Slide change events

---

## Theme Integration

Different themes position and style slide numbers differently:

- **Black theme**: White text, bottom-right
- **White theme**: Black text, bottom-right
- **League theme**: Cyan text, bottom-right with glow
- **Beige theme**: Brown text, bottom-right

**Override with custom CSS:**

```html
<style>
  .reveal .slide-number {
    font-family: monospace;
    font-size: 20px;
    color: #ff6b6b;
  }
</style>
```

---

## Best Practices

1. **Use `c/t` for long presentations** - Helps audience track progress
2. **Use `h.v` for technical talks with nested content** - Shows hierarchy
3. **Consider `showSlideNumber: 'speaker'`** - Keep presentation clean, help presenter
4. **Test visibility** - Ensure numbers are readable against all backgrounds
5. **Be consistent** - Don't change format mid-presentation
6. **For video** - Use `c/t` so viewers can reference specific slides

---

## Summary

- **Enable**: Set `slideNumber: true` or format string
- **Format**: `h.v`, `h/v`, `c`, `c/t`, or custom function
- **Context**: Control visibility with `showSlideNumber`
- **Styling**: CSS customization via `.slide-number` class
- **No timing impact**: Updates instantly, no animation delay
- **Video-friendly**: Appears in recordings when `showSlideNumber: 'all'`
